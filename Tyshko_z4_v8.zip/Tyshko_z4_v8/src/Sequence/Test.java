package Sequence;

public class Test {

	public static void main(String[] args) {
		
		//constructor test
		int[] arr1 = {1, 2, 3, 4, 5};
		int n = 6;
		
		Sequence seq1 = new Sequence(arr1.length, arr1);
		Sequence seq2 = new Sequence(n, 10);
		
		System.out.printf("----CONSTRUCTORS TEST----\n--First--\n");
		seq1.Print();
		System.out.printf("\n--Second--\n");
		seq2.Print();
		System.out.printf("\n");
		
		//methods test
		
		int[] arr2 = {2, 2, 2, 2, 2, 2};
		int[] arr3 = {1, 2, 3, 4, 5, 6};
		int[] arr4 = {10, 6, 4, 1, -71, -81};
		int[] arr5 = {2, 4, 8, 16, 32, 64};
		
		Sequence seq4 = new Sequence(n, arr2);
		Sequence seq5 = new Sequence(n, arr3);
		Sequence seq6 = new Sequence(n, arr4);
		Sequence seq7 = new Sequence(n, arr5);
		Sequence seq8 = new Sequence(n, 19);
		
		System.out.printf("\n----TYPE OF SEQUENCE TEST----\n--");
		seq4.Print();
		System.out.printf("--\n");
		seq4.TypeOfSequence();
		System.out.printf("\n--");
		seq5.Print();
		System.out.printf("--\n");
		seq5.TypeOfSequence();
		System.out.printf("\n--");
		seq6.Print();
		System.out.printf("--\n");
		seq6.TypeOfSequence();
		System.out.printf("\n--");
		seq7.Print();
		System.out.printf("--\n");
		seq7.TypeOfSequence();
		System.out.printf("\n--");
		seq8.Print();
		System.out.printf("--\n");
		seq8.TypeOfSequence();
		System.out.printf("\n");
		
		System.out.printf("\n----METHODS TEST----\n");
		int elem = 1;
		if(seq1.IsBelong(elem)) {
			
			System.out.printf("Element %d belongs to sequence ", elem);
			seq1.Print();
			System.out.printf("\n");
		}
		else {
			
			System.out.printf("Element %d doesn't belong to sequence ", elem);
			seq1.Print();
			System.out.printf("\n");
		}
		
		if(seq5.IsEqual(seq6)) {
			
			System.out.printf("Sequence ");
			seq5.Print();
			System.out.printf(" is equal to sequence ");
			seq6.Print();
			System.out.printf("\n");
		}
		else {
			
			System.out.printf("Sequence ");
			seq5.Print();
			System.out.printf(" is not equal to sequence ");
			seq6.Print();
			System.out.printf("\n");
		}
		
		int min = seq8.MinElement();
		int max = seq8.MaxElement();
		System.out.printf("Sequence ");
		seq8.Print();
		System.out.printf("\nMin element: %d\nMax element: %d", min, max);
		
	}
}

