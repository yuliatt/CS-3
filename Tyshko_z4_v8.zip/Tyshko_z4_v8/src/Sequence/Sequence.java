package Sequence;

import java.util.Random;
import java.util.Date;
import java.util.Arrays;

public class Sequence {

	int length;
	int[] seq = new int[length];

	
	public Sequence() {
		
		this.length = 0;
		this.seq = null;
	}
	
	public Sequence(int length, int[] seq) {
		
		assert(length > 0);
		assert(length == seq.length);
		
		this.length = length;
		this.seq = seq;
	}
	
	public Sequence(int length, int val)	 {
		
		assert(length > 0);
		assert(val > 0);
		
		Initialize(length, val);
	}
	
	public void TypeOfSequence() {
		
		boolean flagIncr = true;
		boolean flagDecr = true;
		boolean flagNonIncr = true;
		boolean flagNonDecr = true;
		boolean flagGeom = true;
		boolean flagArithm = true;
		
		for(int i = 1; i < length; i++) {
			
			if(seq[i - 1] >= seq[i]) {
				
				flagIncr = false;
				break;
			}
		}
		
		for(int i = 1; i < length; i++) {
			
			if(seq[i - 1] <= seq[i]) {
				
				flagDecr = false;
				break;
			}
		}
		
		if(!flagDecr) {
			
			for(int i = 1; i < seq.length; i++) {
			
				if(seq[i - 1] < seq[i]) {
				
					flagNonIncr = false;
					break;
				}
			}
		}
		else flagNonIncr = false;
			
		if(!flagIncr) {
			
			for(int i = 1; i < seq.length; i++) {	
			
				if(seq[i - 1] > seq[i] && !flagIncr) {
				
					flagNonDecr = false;
					break;
				}
			}
		}
		else flagNonDecr = false;
		
		int diff = seq[1] - seq[0];
		double denom = 1;
		
		if (seq[0] != 0) {
			
			denom = seq[1] / seq[0];
		}
		else flagGeom = false;
		
		for(int i = 1; i < length - 1; i++) {
			
			if(diff == 0 || seq[i + 1] - seq[i] != diff) {
				
				flagArithm = false;
				break;
			}
		}
			
		for(int i = 1; i < length - 1; i++) {	
			
			if(denom == 1 || (seq[i] != 0 && seq[i + 1] / seq[i] != denom)) {
				
				flagGeom = false;
				break;
			}
		}
		
		if(flagGeom) System.out.printf("Geometric ");
		if(flagArithm) System.out.printf("Arithmetic ");
		if(flagIncr) System.out.printf("Increasing ");
		if(flagDecr) System.out.printf("Decreasing ");
		if(flagNonIncr) System.out.printf("Non-Increasing ");
		if(flagNonDecr) System.out.printf("Non-Decreasing ");
		if(!flagGeom && !flagArithm && !flagIncr && !flagDecr && !flagNonIncr && !flagNonDecr) System.out.printf("No such type");	 
	}
	
	public boolean IsBelong(int val) {
		
		for(int i = 0; i < length; i++) {
			
			if(seq[i] == val)
				return true;
		}
		
		return false;
	}
	
	public boolean IsEqual(Sequence seq1) {
		
		if(this.length != seq1.length)
			return false;
		else return Arrays.equals(this.seq, seq1.seq);
	}
	
	public int MaxElement() {
		
		int max = seq[0];
		
		for(int i = 1; i < length; i++) {
			
			if(seq[i] > max)
				max = seq[i];
		}
		
		return max;
	}
	
	public int MinElement() {
		
		int min = seq[0];
		
		for(int i = 1; i < length; i++) {
			
			if(seq[i] < min)
				min = seq[i];
		}
		
		return min;
	}
	
	public void Print() {
			
		System.out.printf(Arrays.toString(seq));
	
	}
	
	private void Initialize(int len, int val) {
        
		assert(len > 0);
        assert(val > 0);
        
        seq = new int [len];
        length = len;
        
        Random rand = new Random((new Date()).getTime());
        
        for(int i = 0; i < length; i++) {
            
        	seq[i] = rand.nextInt(val);
        }
    }
}

