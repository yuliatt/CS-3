import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;
import java.io.*;
import java.util.StringTokenizer;
import java.text.ParseException;


public class Subscriber implements Serializable {
    private static final long serialVersionUDI = 1L;

    String initials;
    static final String P_Initials = "Initials";

    //один ко многоим
    String district;
    static final String P_District = "District";

    String adress;
    static final String P_Adress = "Adress";

    String telephone;
    static final String P_Telephone = "Telephone";

    String contractNumber;
    static final String P_ContractNumber = "Contract Number";

    String contractDate;
    static final String P_ContractDate = "Contract Date";

    //без повторов
    String subscriptionFee;
    static final String P_SubscriptionFee = "Subscription Fee";

    //без повторов
    String lastPaymentDate;
    static final String P_LastPaymentDate = "Last Payment Date";

    static Boolean validDate(String str) {
        StringTokenizer st = new StringTokenizer(str, ".");
        if (st.countTokens() != 3) {
            return false;
        }
        GregorianCalendar date = new GregorianCalendar();
        date.setLenient(false);
        int day = Integer.parseInt(st.nextToken());
        int month = Integer.parseInt(st.nextToken());
        int year = Integer.parseInt(st.nextToken());
        date.set(year, month, day);
        date.getTime();
        return true;
    }

    public static Boolean nextRead( Scanner fin, PrintStream out ) {
        return nextRead( P_Initials, fin, out );
    }

    static Boolean nextRead( final String prompt, Scanner fin, PrintStream out ) {
        out.print( prompt );
        out.print( ": " );
        return fin.hasNextLine();
    }


    public static Subscriber read(Scanner fin, PrintStream out ) throws IOException {

        String str;
        Subscriber subscriber = new Subscriber();

        subscriber.initials = fin.nextLine();

        if ( ! nextRead(P_District, fin, out )) return null;
        subscriber.district = fin.nextLine();

        if ( ! nextRead(P_Adress, fin, out )) return null;
        subscriber.adress = fin.nextLine();

        if ( ! nextRead(P_Telephone, fin, out )) return null;
        subscriber.telephone = fin.nextLine();

        if ( ! nextRead(P_ContractNumber, fin, out )) return null;
        subscriber.contractNumber = fin.nextLine();

        if ( ! nextRead( P_ContractDate, fin, out )) return null;
        subscriber.contractDate = fin.nextLine();
        if (!Subscriber.validDate(subscriber.contractDate))
            throw new IOException("Invalid date value");

        if ( ! nextRead( P_SubscriptionFee, fin, out )) return null;
        subscriber.subscriptionFee = fin.nextLine();

        if ( ! nextRead( P_LastPaymentDate, fin, out )) return null;
        subscriber.lastPaymentDate = fin.nextLine();
        if (!Subscriber.validDate(subscriber.lastPaymentDate))
            throw new IOException("Invalid date value");

        return subscriber;
    }

    public Subscriber() {
    }

    public String toString() {
        return new String(
                initials + " | " +
                        district + " | " +
                        adress + " | " +
                        telephone + " | " +
                        contractNumber + " | " +
                        contractDate + " | " +
                        subscriptionFee + " | " +
                        lastPaymentDate
        );
    }
}