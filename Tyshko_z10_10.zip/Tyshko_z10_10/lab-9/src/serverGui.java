
import javax.swing.*;

public class serverGui extends JWindow {
    private JComboBox comboBox1;
    private JPanel panel1;

    serverGui(){
        setSize(1000,1000);

    }
}
