package cliver.servent;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Message implements Serializable {
    public  String CODE;
    public  String user;
    public  Message(){};

    public Message(String code, String user) {
        this.CODE = code;
        this.user = user;
    }

    @Override
    public String toString() {
        return "Message{" +
                "CODE='" + CODE + '\'' +
                ", user='" + user + '\'' +
                '}';
    }
}