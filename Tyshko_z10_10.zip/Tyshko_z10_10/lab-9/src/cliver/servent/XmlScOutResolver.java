package cliver.servent;

import javax.xml.bind.SchemaOutputResolver;
import javax.xml.transform.Result;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;

public class XmlScOutResolver extends SchemaOutputResolver {
    String baseDirNameS;
    String classNameS;

    public XmlScOutResolver(String baseDirNameS, String classNameS) {
        this.baseDirNameS = baseDirNameS;
        this.classNameS = classNameS;
    }


    public Result createOutput(
            String namespaceUri, String suggestedFileName )
            throws IOException {
        return new StreamResult(
                new File(baseDirNameS, classNameS));
    }
}
