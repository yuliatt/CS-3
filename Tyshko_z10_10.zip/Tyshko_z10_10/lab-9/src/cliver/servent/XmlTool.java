package cliver.servent;

import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.bind.*;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import java.io.*;

public class XmlTool {
    public static void createXmlSchema(String directory,Class<? extends Message> message) throws JAXBException, IOException {
        JAXBContext jaxbContext = JAXBContext.newInstance(message);
        jaxbContext.generateSchema(new XmlScOutResolver(directory,message.getName()));
    }
    private static Object sync_xmlValidToXsd = new Object();

    public static boolean xmlValidToXsd( String xml, String schemaName) { synchronized (sync_xmlValidToXsd) {

        Source schemaFile = new StreamSource(new File(schemaName));
        Source xmlFile = new StreamSource( new StringReader(xml));
        SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema;

               try {

            schema = schemaFactory.newSchema(schemaFile);

        } catch (org.xml.sax.SAXException e1) {
            System.err.println( "Can't create schema from " + schemaFile);

            return false;

        }
        javax.xml.validation.Validator validator = schema.newValidator();

        try{

            validator.validate(xmlFile);

        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return true;

    }

    }
    public static String toXml(Message message) throws IOException, JAXBException {
        try(ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(512))
        {
            StringBuilder d = new StringBuilder();
            JAXBContext context = JAXBContext.newInstance(message.getClass());
            Marshaller m = context.createMarshaller();
            m.marshal(message,byteArrayOutputStream);
            d.append(byteArrayOutputStream.toString());
            byteArrayOutputStream.flush();
            return d.toString();
        }
    }
    public static Message fromXml(String d) throws IOException, JAXBException {

        try(ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(d.getBytes()))
        {

            Unmarshaller unmarshaller = JAXBContext.newInstance(Message.class).createUnmarshaller();
            return (Message) unmarshaller.unmarshal(byteArrayInputStream);
        }
    }

    public static void main(String[] args) throws IOException, JAXBException {
        System.out.println( toXml(new Message("0","0")));
        System.out.println( xmlValidToXsd(toXml(new Message("0", "0")), "xsdFile"));
    }
}
