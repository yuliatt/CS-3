package cliver.servent;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.xml.bind.JAXBException;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;


public class Client {

    public static Socket socket;
    public static ObjectOutputStream bos;
    public static ObjectInputStream bis;
    public static String address;
    public static Crosses crosses;
    public static int nSize;
    static int point;
    static String port;
     private BufferedReader reader;

    public static void main(String[] args) {
        Login login = new Login();
        login.setLocationRelativeTo(null);
        login.setVisible(true);
        while(!login.bOkFlag)
        {
            System.out.print("");
        }
        try {
            socket = new Socket(address,Integer.parseInt( port));
        } catch (IOException e) {
            new WaitingDialog( "Can't connect to the server").setLocationRelativeTo(null);
            try {
                Thread.sleep(5000);
            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
            System.exit(4);
        }
        String str;

        try {
            System.out.println("Success");
            WaitingDialog dialog = new WaitingDialog("Connected. Waiting for second player");
            dialog.setLocationRelativeTo(null);
            bos = new ObjectOutputStream(socket.getOutputStream());
            bis = new ObjectInputStream(socket.getInputStream());
            nSize = bis.readInt();
            /*new ReadMsg().start();
            new WriteMsg().start();
            bos.write(Files.readAllBytes(Paths.get("company.Message.xsd")));*/
            bos.flush();

            point = bis.readInt();
            dialog.dispose();
             do{
                switch (nSize)
            {
                case 3:
                    CrossesProc();
                    break;
            }

                PlayAgainDialog playAgainDialog  = new PlayAgainDialog();
                 playAgainDialog.setLocationRelativeTo(crosses);
                 playAgainDialog.setVisible(true);
                 while (!playAgainDialog.flag){
                    System.out.print("");
                };
                if(socket.isClosed())break;
                int check = bis.readInt();
                System.err.println(check);
                 if (check != 44) {
                     System.exit(check);
                 }
                 System.out.println("Again");
             }while (!socket.isClosed());
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Disconnected");
            System.exit(2);
        }
    }

    public static void CrossesProc() throws IOException, ClassNotFoundException {
        crosses =  new Crosses();
        crosses.setLocationRelativeTo(null);
        crosses.label1.setText(point == 1? "X":"0");
        Object obj;
        Message msg;
        crosses.pack();
        int flag = -1;
        while(!socket.isClosed()&& flag!=0) {
            flag--;
            obj = bis.readObject();
            msg = (Message)obj;
            System.out.println(msg.CODE);

            switch (msg.CODE)
            {
                case "1":
                    crosses.button1.setText(msg.user.equals("1")? "X":"0");
                    crosses.button1.setEnabled(false);
                    crosses.button1.updateUI();
                    break;
                case "2":
                    crosses.button2.setText(msg.user.equals("1")? "X":"0");
                    crosses.button2.setEnabled(false);
                    crosses.button1.updateUI();
                    break;
                case "3":
                    crosses.button3.setText(msg.user.equals("1")? "X":"0");
                    crosses.button3.setEnabled(false);
                    break;
                case "4":
                    crosses.button4.setText(msg.user.equals("1")? "X":"0");
                    crosses.button4.setEnabled(false);
                    break;
                case "5":
                    crosses.button5.setText(msg.user.equals("1")? "X":"0");
                    crosses.button5.setEnabled(false);
                    break;
                case "6":
                    crosses.button6.setText(msg.user.equals("1")? "X":"0");
                    crosses.button6.setEnabled(false);
                    break;
                case "7":
                    crosses.button7.setText(msg.user.equals("1")? "X":"0");
                    crosses.button7.setEnabled(false);
                    break;
                case "8":
                    crosses.button8.setText(msg.user.equals("1")? "X":"0");
                    crosses.button8.setEnabled(false);
                    break;
                case "9":
                    crosses.button9.setText(msg.user.equals("1")? "X":"0");
                    crosses.button9.setEnabled(false);
                    break;
                case "17":
                    crosses.label1.setText("Victory");
                    flag = 0;
                    crosses.lockInput();
                    break;
                case "18":
                    crosses.label1.setText("Defeat");
                    flag = 0;
                    crosses.lockInput();
                    break;
                case "19":
                    crosses.label1.setText("Draw");
                    flag = 0;
                    crosses.lockInput();
                    break;
                case "-1":System.out.println("S");
                    break;
            }
        }
    }

    private static class ReadMsg extends Thread {
        @Override
        public void run() {
            super.run();
            Message message;
            try {
                System.out.println("OK");
                while (true) {
                    String xmlMessage = bis.readUTF();
                    if(!XmlTool.xmlValidToXsd(xmlMessage, "xsdFile"))
                    {
                        System.err.println("Invalid XML");
                        continue;
                    }
                    message = XmlTool.fromXml(xmlMessage);

                    switch (message.CODE) {

                        case "0":
                            CrossesProc();
                            break;
                        case "1":
                            crosses.button1.setText(message.user.equals("1")? "X":"0");
                            crosses.button1.setEnabled(false);
                            crosses.button1.updateUI();
                            break;
                        case "2":
                            crosses.button2.setText(message.user.equals("1")? "X":"0");
                            crosses.button2.setEnabled(false);
                            break;
                        case "3":
                            crosses.button3.setText(message.user.equals("1")? "X":"0");
                            crosses.button3.setEnabled(false);
                            break;
                        case "4":
                            crosses.button4.setText(message.user.equals("1")? "X":"0");
                            crosses.button4.setEnabled(false);
                            break;
                        case "5":
                            crosses.button5.setText(message.user.equals("1")? "X":"0");
                            crosses.button5.setEnabled(false);
                            break;
                        case "6":
                            crosses.button6.setText(message.user.equals("1")? "X":"0");
                            crosses.button6.setEnabled(false);
                            break;
                        case "7":
                            crosses.button7.setText(message.user.equals("1")? "X":"0");
                            crosses.button7.setEnabled(false);
                            break;
                        case "8":
                            crosses.button8.setText(message.user.equals("1")? "X":"0");
                            crosses.button8.setEnabled(false);
                            break;
                        case "9":
                            crosses.button9.setText(message.user.equals("1")? "X":"0");
                            crosses.button9.setEnabled(false);
                            break;
                        case "17":
                            crosses.label1.setText("Victory");
                            crosses.lockInput();
                            PlayAgainDialog playAgainDialog  = new PlayAgainDialog();
                            playAgainDialog.setLocationRelativeTo(crosses);
                            playAgainDialog.setVisible(true);
                            while (!playAgainDialog.flag){
                                System.out.print("");
                            };
                            break;
                        case "18":
                            crosses.label1.setText("Defeat");
                            crosses.lockInput();
                            PlayAgainDialog playAgainDialog1  = new PlayAgainDialog();
                            playAgainDialog1.setLocationRelativeTo(crosses);
                            playAgainDialog1.setVisible(true);
                            while (!playAgainDialog1.flag){
                                System.out.print("");
                            };
                            break;
                        case "19":
                            crosses.label1.setText("Draw");
                            crosses.lockInput();
                            PlayAgainDialog playAgainDialog2  = new PlayAgainDialog();
                            playAgainDialog2.setLocationRelativeTo(crosses);
                            playAgainDialog2.setVisible(true);
                            while (!playAgainDialog2.flag){
                                System.out.print("");
                            };
                            break;
                        case "22":
                            WaitingDialog dialog = new WaitingDialog("Answer checked. Waiting for second player");
                            break;
                        case "44":
                            System.out.println("Game begin again");
                            CrossesProc();
                            break;

                        case "50":
                            socket.close();
                            System.out.println("Disconnected");
                            break;
                    }
                }
            }
            catch (IOException | JAXBException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public static class WriteMsg extends Thread {

        @Override
        public void run() {

            System.out.println("OK");
            LoggedPrintStream lpsOut = LoggedPrintStream.create(System.out);
            System.setOut(lpsOut);

            while (true) {
                try {
                    System.setOut(lpsOut.underlying);
                    String in = lpsOut.buf.toString();
                    switch (in){
                        case "0":
                            bos.writeUTF(XmlTool.toXml(new Message("0", "0")));
                            break;
                        case "1":
                            bos.writeUTF(XmlTool.toXml(new Message("1", "0")));
                            break;
                        case "2":
                            bos.writeUTF(XmlTool.toXml(new Message("2", "0")));
                            break;
                        case "3":
                            bos.writeUTF(XmlTool.toXml(new Message("3","0")));
                            break;
                        case "4":
                            bos.writeUTF(XmlTool.toXml(new Message("4", "0")));
                            break;
                        case "5":
                            bos.writeUTF(XmlTool.toXml(new Message("5", "0")));
                            break;
                        case "6":
                            bos.writeUTF(XmlTool.toXml(new Message("6", "0")));
                            break;
                        case "7":
                            bos.writeUTF(XmlTool.toXml(new Message("7", "0")));
                            break;
                        case "8":
                            bos.writeUTF(XmlTool.toXml(new Message("8", "0")));
                            break;
                        case "9":
                            bos.writeUTF(XmlTool.toXml(new Message("9", "0")));
                            break;
                        case "17":
                            bos.writeUTF(XmlTool.toXml(new Message("17", "0")));
                            break;
                        case "18":
                            bos.writeUTF(XmlTool.toXml(new Message("18", "0")));
                            break;
                        case "19":
                            bos.writeUTF(XmlTool.toXml(new Message("19", "0")));
                            break;
                        case "22":
                            bos.writeUTF(XmlTool.toXml(new Message("22", "0")));
                            break;
                        case "44":
                            bos.writeUTF(XmlTool.toXml(new Message("44","0")));
                            break;

                        case "50":
                            bos.writeUTF(XmlTool.toXml(new Message("50", "0")));
                            break;
                    }

                    bos.flush();

                } catch (IOException | JAXBException e) {
                    e.printStackTrace();
                    try {
                        Client.socket.close();
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                }
            }
        }
    }
}

