package cliver.servent;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public  class Connection extends Thread{
    public  byte ID;
    public Socket socket;
    public static ObjectOutputStream bos;
    public static ObjectInputStream bis;
    public static int plCounter = 0;

    public Connection(Socket s) {

        Server.serverUI.textArea1.append(s.getInetAddress().getHostName() + " connected to the server\n");
        for (byte i = 0; i < 2; i++) {
            if(!Server.connections.isEmpty())
            for (Connection d: Server.connections
            ) {
                if(d.ID!=i){
                    ID = i;
                    socket = s;
                    start();
                    return;
                };
            }
            else{
                ID = i;
                socket = s;
                start();
                break;
            }
        }

    }

    @Override
    public void run() {
        try {
            super.run();
            byte[] bytes = new byte[1024];
            Message message;
            String prevCode = "-1";
            while (!socket.isClosed()) {
                int code = (int) Server.connectionStreams.get(ID).ois.readObject();
                synchronized (Server.messages){
                     if(code > Server.nFieldSize* Server.nFieldSize){
                         Server.playAgain+=code;
                         System.out.println("check");
                         plCounter++;
                         if (plCounter == 2) {
                             System.out.println("check");
                            for (ConnectionStream c : Server.connectionStreams
                            ) {
                                c.oos.writeInt(Server.playAgain);
                                c.oos.flush();
                            }
                            Server.bPlayAgainSet = true;
                            plCounter = 0;
                         }
                    }
                     synchronized (Server.lastPlayer) {
                         if (ID != Integer.parseInt(Server.lastPlayer)) {
                             System.out.println(ID + ":" + code);
                             Server.lastPlayer = Byte.toString(ID);
                             Server.messages.add(new Message(Integer.toString(code), Byte.toString(ID)));
                         }
                     }
                }

                synchronized (Server.connections){
                    if (!Server.messages.isEmpty()) {
                        Message msg = Server.messages.get(Server.messages.size() - 1);
                        if (!msg.CODE.equals(prevCode) && Integer.parseInt(msg.CODE) <= Server.nFieldSize * Server.nFieldSize) {
                            prevCode = msg.CODE;
                            Server.field[(Integer.parseInt(msg.CODE) - 1) / Server.nFieldSize][(Integer.parseInt(msg.CODE) - 1) % Server.nFieldSize]
                                    = Byte.parseByte(msg.user);
                            synchronized (Server.connections) {
                                for (Connection d :
                                        Server.connections) {
                                    Server.connectionStreams.get(d.ID).oos.writeObject(msg);
                                    Server.connectionStreams.get(d.ID).oos.flush();
                                }
                            }
                        }
                    }
                }

            }
            System.out.println("OK");
            while (true) {
                String xmlMessage = bis.readUTF();
                if (!XmlTool.xmlValidToXsd(xmlMessage, "xsdFile")) {
                    System.err.println("Invalid XML");
                    continue;
                }
                message = XmlTool.fromXml(xmlMessage);

                switch (message.CODE) {

                    case "0":
                        bos.writeUTF(XmlTool.toXml(new Message("0", message.user)));
                    case "1":
                        bos.writeUTF(XmlTool.toXml(new Message("1", message.user)));
                        break;
                    case "2":
                        bos.writeUTF(XmlTool.toXml(new Message("2", message.user)));
                        break;
                    case "3":
                        bos.writeUTF(XmlTool.toXml(new Message("3", message.user)));
                        break;
                    case "4":
                        bos.writeUTF(XmlTool.toXml(new Message("4", message.user)));
                        break;
                    case "5":
                        bos.writeUTF(XmlTool.toXml(new Message("5", message.user)));
                        break;
                    case "6":
                        bos.writeUTF(XmlTool.toXml(new Message("6", message.user)));
                        break;
                    case "7":
                        bos.writeUTF(XmlTool.toXml(new Message("7", message.user)));
                        break;
                    case "8":
                        bos.writeUTF(XmlTool.toXml(new Message("8", message.user)));
                        break;
                    case "9":
                        bos.writeUTF(XmlTool.toXml(new Message("9", message.user)));
                        break;
                    case "17":
                        bos.writeUTF(XmlTool.toXml(new Message("17", message.user)));
                        break;
                    case "18":
                        bos.writeUTF(XmlTool.toXml(new Message("18", message.user)));
                        break;
                    case "19":
                        bos.writeUTF(XmlTool.toXml(new Message("19", message.user)));
                        break;
                    case "22":
                        bos.writeUTF(XmlTool.toXml(new Message("22", message.user)));
                        break;
                    case "44":
                        bos.writeUTF(XmlTool.toXml(new Message("44", message.user)));
                        break;
                    case "50":
                        bos.writeUTF(XmlTool.toXml(new Message("50", message.user)));
                        break;
                }
            }
        } catch (Exception e) {
            Server.serverUI.textArea1.append(socket.getInetAddress().getHostName() + " has disconnected\n");
            try {
                Server.connections.get(ID^ID).socket.close();
                Server.serverSocket.close();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            Server.bSomeoneDisconnected = true;
            Server.bPlayAgainSet = true;
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}