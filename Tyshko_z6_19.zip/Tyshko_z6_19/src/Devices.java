
import java.io.Serializable;
import java.text.DateFormat;
import java.util.Date;

public class Devices implements Serializable{
    public int pow=0;
    public int wei=0;
    public final Date creationDate = new Date();
    public String getCreationDate() {
        DateFormat dateFormatter = DateFormat.getDateTimeInstance(
                DateFormat.DEFAULT, DateFormat.DEFAULT, AppLocale.get());
        String dateOut = dateFormatter.format(creationDate);
        return dateOut;
    }

    private static final long serialVersionUID = 1L;
    protected Devices( int wei)
    {
        this.wei=wei;
    }
    public Devices() {}

    public int get_pow()
    {
        return pow;
    }

    public String toString() {
        return new String("; "+AppLocale.getString( AppLocale.pow) + ": " + pow + "; " +
                AppLocale.getString( AppLocale.wei ) + ": " + wei + "; " +
                AppLocale.getString( AppLocale.creation ) + ": " + getCreationDate()+"; " );
    }
}
