
import java.io.*;
import java.util.ArrayList;

public class Connector {

    private String filename;

    public Connector( String filename ) {
        this.filename = filename;
    }

    public void write(Device salad) throws IOException {
        FileOutputStream fos = new FileOutputStream (filename);
        try ( ObjectOutputStream oos = new ObjectOutputStream( fos )) {
            oos.writeInt( salad.dev.size() );
            for ( Devices v: salad.dev) {
                oos.writeObject(v);
            }
            oos.flush();
        }
    }

    public ArrayList<Devices> read() throws IOException, ClassNotFoundException {
        FileInputStream fis = new FileInputStream(filename);
        try ( ObjectInputStream oin = new ObjectInputStream(fis)) {
            int length = oin.readInt();
            ArrayList<Devices> result=new  ArrayList<Devices>(length);
			/*for ( devetables v: result) {
				v= (devetables) oin.readObject();
				result.add(v);
			}*/
            Devices v=new Devices();
            while(length>0)
            {
                v= (Devices) oin.readObject();
                result.add(v);
                length--;
            }
            return result;
        }
    }
}