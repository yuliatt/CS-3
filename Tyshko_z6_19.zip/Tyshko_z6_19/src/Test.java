
import java.util.ArrayList;

import java.util.*;

public class Test {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ArrayList<Devices> dev= new ArrayList<Devices>();
        dev.add(new Iron(120, Iron.Type.steam));
        dev.add(new Iron(20, Iron.Type.simple));
        dev.add(new TV(140, TV.Type_tv.red));
        dev.add(new Computer(100, 3));
        dev.add(new Toaster(30, Toaster.Type_t.green));
        Device myDevices=new Device(dev);
        System.out.println(AppLocale.Power_consumption+": "+myDevices.allPower());
        System.out.println("Вывод подключенных приборов без sort and serialization");
        myDevices.printDevices();
        myDevices.dev.sort(myDevices);

        System.out.println("_______________________________________________________________");
        System.out.println("Приборы отсортированы по мощности, after serialization");
        myDevices.printDevices();

        System.out.println("enter your region(RU,BY,GB)");
        Scanner in=new Scanner(System.in);
        String s=in.nextLine();
        //String s=args[0];
        Locale loc;
        switch(s) {
            case "GB":
                loc=new Locale("en", "GB");
                Locale.setDefault(loc);
                AppLocale.set(loc);
                break;
            case "RU":
                loc=new Locale("ru", "RU");
                Locale.setDefault(loc);
                AppLocale.set(loc);
                break;
            case "BY":
                loc=new Locale("be", "BY");
                Locale.setDefault(loc);
                AppLocale.set(loc);
                break;
            default:
                System.out.println("Check your input, it's incorrect!");
                loc=new Locale("en", "GB");
                Locale.setDefault(loc);
                AppLocale.set(loc);
                break;
        }


        try {
            Connector con = new Connector("Devices.dat");
            con.write(myDevices);
            ArrayList<Devices> dvcs= con.read();
            System.out.println( "Devices: ");

            for ( Devices n : dvcs ) {
                System.out.println( n.toString() );
            }
            int a=10, b=40;
            System.out.println("_______________________________________________________________");
            myDevices.RangeOfCals(a,b);
        }
        catch ( Exception e ) {
            System.err.println(e);
        }
    }

}
