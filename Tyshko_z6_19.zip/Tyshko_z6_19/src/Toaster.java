import java.io.Serializable;

public class Toaster extends Devices implements Serializable{

    public enum Type_t {green, black}
    private static final long serialVersionUID = 1L;
    public Type_t toaster_type;
    private final int pow_100g=115;

    public Toaster(int wei, Type_t toaster_type)
    {
        super(wei);
        this.toaster_type= toaster_type;
        this.pow=this.wei*pow_100g/100;
    }
    public String toString()
    {
        return new String(AppLocale.getString(AppLocale.Toaster)+ super.toString() +
                "; "+ AppLocale.getString(AppLocale.toaster_type)+
                ":"+AppLocale.getString(toaster_type.toString()));
    }
}
