
import java.io.Serializable;
public class TV extends Devices implements Serializable{
    /*transient*/ //String colour;
    public enum Type_tv {red, black}
    private final int pow_100g=18;
    private static final long serialVersionUID = 1L;
    public TV.Type_tv colour;
    public TV(int wei, TV.Type_tv colour)
    {
        super(wei);
        this.colour=colour;
        this.pow=this.wei*pow_100g/100;
    }
    public String toString()
    {
        return new String(AppLocale.getString(AppLocale.TV)+ super.toString() +
                "; "+ AppLocale.getString(AppLocale.colour)+
                ":"+AppLocale.getString(colour.toString()));
    }
}
