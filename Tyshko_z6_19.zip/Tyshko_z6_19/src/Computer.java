
import java.io.Serializable;

public class Computer extends Devices implements Serializable{
    int amount=0;
    private final int pow_100g=16;
    private static final long serialVersionUID = 1L;
    public Computer(int wei, int amount)
    {
        super(wei);
        this.amount=amount;
        this.pow=this.wei*pow_100g/100*amount;
    }
    public String toString()
    {
        return new String(AppLocale.getString(AppLocale.Computer)+ super.toString() +
                AppLocale.getString(AppLocale.amount)+": " +amount);
    }
}
