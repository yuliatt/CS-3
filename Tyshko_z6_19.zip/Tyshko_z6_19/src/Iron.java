
import java.io.Serializable;
public class Iron extends Devices implements Serializable {
    public enum Type{steam, simple, white}
    private final int pow_100g=40;
    private static final long serialVersionUID = 1L;
    public Type iron_type;
    public Iron(int wei, Type iron_type)
    {
        super(wei);
        this.iron_type=iron_type;
        this.pow=this.wei*pow_100g/100;
    }
    public String toString()
    {
        return new String(AppLocale.getString(AppLocale.Iron)+ super.toString() +
                "; "+ AppLocale.getString(AppLocale.iron_type)+
                ":"+AppLocale.getString(iron_type.toString()));
    }
}
