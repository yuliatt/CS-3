
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;

public class Device implements Comparator<Devices>, Serializable{
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    public ArrayList<Devices> dev;

    public Device(ArrayList<Devices> arrl)  {
        dev=new ArrayList<Devices>();
        dev=arrl;
    }
    int allPower()
    {
        int pow=0;
        for(Devices devs: dev)
        {
            pow+=devs.pow;
        }
        return pow;
    }
    public void printDevices()
    {
        for(Devices v: dev)
        {
            System.out.println(v.toString());
        }
    }
    public void RangeOfCals(int a,int b) throws Exception
    {
        System.out.println("Devices from range{"+a+";"+b+"}:");
        if(a>b)
        {
            int temp=a;
            a=b;
            b=temp;
        }
        if(a<0 || b<=a) throw new Exception("Range is incorrect!");
        int c=0;
        for(Devices v: dev)
        {
            if(v.pow <=b && v.pow>=a)
            {
                System.out.println(v.toString());
            }
            else c++;
        }
        if(c==dev.size()) {
            System.out.println("There are no devices in this range");
        }
        System.out.println();
    }

    @Override
    public int compare(Devices lhs, Devices rhs) {
        // TODO Auto-generated method stub
        if(lhs.get_pow()==rhs.get_pow())
            return 0;
        if(lhs.get_pow()>rhs.get_pow())
            return 1;
        if(lhs.get_pow()<rhs.get_pow())
            return -1;
        return -1;
    }
}
