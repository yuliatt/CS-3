
import java.util.Locale;
import java.util.ResourceBundle;

public class AppLocale {
    private static final String strMsg = "Msg";
    private static Locale loc = Locale.getDefault();
    private static ResourceBundle res =
            ResourceBundle.getBundle( AppLocale.strMsg, AppLocale.loc );

    static Locale get() {
        return AppLocale.loc;
    }

    static void set( Locale loc ) {
        AppLocale.loc = loc;
        res = ResourceBundle.getBundle( AppLocale.strMsg, AppLocale.loc );
    }

    static ResourceBundle getBundle() {
        return AppLocale.res;
    }

    static String getString( String key ) {
        return AppLocale.res.getString(key);
    }

    // Resource keys:
    public static final String Computer="Computer";
    public static final String Toaster="Toaster";
    public static final String Iron="Iron";
    public static final String TV="TV";
    public static final String pow="pow";
    public static final String wei="wei";
    public static final String creation="creation";
    public static final String Device="Device";
    public static final String colour="colour";
    public static final String amount="amount";
    public static final String toaster_type ="toaster_type";
    public static final String black="black";
    public static final String green="green";
    public static final String iron_type="iron_type";
    public static final String steam="steam";
    public static final String simple="simple";
    public static final String white="white";
    public static final String devices="devices";
    public static final String red="red";
    public static final String Power_consumption="Power consumption";
}

