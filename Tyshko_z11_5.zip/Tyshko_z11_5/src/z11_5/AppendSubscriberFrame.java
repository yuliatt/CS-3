package z11_5;

import javax.swing.*;
import java.awt.*;

public class AppendSubscriberFrame extends JDialog
{
    private final JTextField initials;
    private final JTextField distirict;
    private final JTextField adress;
    private final JTextField telephone;
    private final JTextField contactNumber;
    private final JTextField contractDate;
    private final JTextField subscriptionFee;
    private final JTextField lastPaymentDate;

    public boolean flag;
    private static final long serialVersionUID = 1L;

    public AppendSubscriberFrame(JFrame owner)
    {
        super(owner,"Enter your data",true);
        setSize(350, 500);
        Toolkit kit=Toolkit.getDefaultToolkit();
        setLocation(kit.getScreenSize().width / 2 - 400,
                kit.getScreenSize().height/2 - 275);
        Container contentPane=getContentPane();
        setResizable(true);
        setLayout(new FlowLayout(FlowLayout.CENTER,100,5));

        contentPane.add(new JLabel("Initials"));
        initials = new JTextField("",25);
        contentPane.add(initials);

        contentPane.add(new JLabel("District"));
        distirict = new JTextField("",25);
        contentPane.add(distirict);

        contentPane.add(new JLabel("Adress"));
        adress = new JTextField("",25);
        contentPane.add(adress);

        contentPane.add(new JLabel("Telephone"));
        telephone = new JTextField("",25);
        contentPane.add(telephone);

        contentPane.add(new JLabel("Contract Number"));
        contactNumber = new JTextField("",25);
        contentPane.add(contactNumber);

        contentPane.add(new JLabel("Contract Date (DD.MM.YYYY)"));
        contractDate = new JTextField("",25);
        contentPane.add(contractDate);

        contentPane.add(new JLabel("Subscription Fee"));
        subscriptionFee = new JTextField("",25);
        contentPane.add(subscriptionFee);

        contentPane.add(new JLabel("Last Payment Date (DD.MM.YYYY)"));
        lastPaymentDate = new JTextField("",25);
        contentPane.add(lastPaymentDate);

        flag=false;
        JButton ok = new JButton("Ok");
        contentPane.add(ok);
        ok.addActionListener(event -> {
            flag=true;
            setVisible(false);
        });
        JButton cancel=new JButton("Cancel");
        contentPane.add(cancel);
        cancel.addActionListener(event -> setVisible(false));
    }
    public String getInitials(){ return this.initials.getText(); }
    public String getDistrict(){ return this.distirict.getText(); }
    public String getAdress(){ return this.adress.getText(); }
    public String getTelephone(){ return this.telephone.getText(); }
    public String getContractNumber(){ return this.contactNumber.getText(); }
    public String getContractDate(){ return this.contractDate.getText(); }
    public String getSubscriptionFee(){ return this.subscriptionFee.getText(); }
    public String getLastPaymentDate(){ return this.lastPaymentDate.getText(); }

}


