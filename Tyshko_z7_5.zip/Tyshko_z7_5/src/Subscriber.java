import java.io.Serializable;
import java.util.Scanner;

public class Subscriber implements Serializable {
    String initials;
    String district;
    String adress;
    String telephone;
    String contractNumber;
    String contractDate;
    String subscriptionFee;
    String lastPaymentDate;

    public static Subscriber read(Scanner fin ) {
        Subscriber subscriber = new Subscriber();
        subscriber.initials = fin.nextLine();
        if ( ! fin.hasNextLine()) return null;
        subscriber.district = fin.nextLine();
        if ( ! fin.hasNextLine()) return null;
        subscriber.adress = fin.nextLine();
        if ( ! fin.hasNextLine()) return null;
        subscriber.telephone = fin.nextLine();
        if ( ! fin.hasNextLine()) return null;
        subscriber.contractNumber = fin.nextLine();
        if ( ! fin.hasNextLine()) return null;
        subscriber.contractDate = fin.nextLine();
        if ( ! fin.hasNextLine()) return null;
        subscriber.subscriptionFee = fin.nextLine();
        if ( ! fin.hasNextLine()) return null;
        subscriber.lastPaymentDate = fin.nextLine();
        return subscriber;
    }

    public Subscriber() {
    }

    public String toString() {
        return new String (initials + "|" + district + "|" +
                            adress + "|" + telephone + "|" +
                            contractNumber + "|" + contractDate + "|" +
                            subscriptionFee + "|" + lastPaymentDate
        );
    }
}
