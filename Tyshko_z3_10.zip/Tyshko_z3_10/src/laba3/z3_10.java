package laba3;

import java.util.Scanner;
import java.util.Arrays;
import java.util.Random;

public class z3_10 {
	public static void main(String[] args) {
		
		 Scanner in = new Scanner(System.in);
		 System.out.print("Enter n: ");
		 int n = in.nextInt();
		 if ( n <= 1 ) {
		 System.err.println("Invalid n value (require: n > 1)");
		 System.exit( 1 );
		 }
		 
	 int[][] a = new int [n][n];
	 Random rnd = new Random();
	 rnd.setSeed( System.currentTimeMillis() );
	 System.out.println("Source matrix: ");
	 for (int i = 0; i < n; i++) {
	 for (int j = 0; j < n; j++) {
	 int temp = rnd.nextInt();
	 a[i][j] = temp % (n + 1);
	 }
	 }
	 
	 for (int i = 0; i < a.length; i++){
         for (int j = 0; j < a[i].length; j++)
             System.out.print(a[i][j] + "    ");
         System.out.println();
     }
	 System.out.println();
	 
	 int[][] b = Arrays.copyOf(a, a.length);
     
     for (int i = 0; i < b.length; i++) {
         int c = 0;
         int[] temp = new int[b.length];
         for (int j = 0; j < b.length; j++) {
             if (b[i][j] != 0) {
                 temp[c++] = b[i][j];
             }
         }
         b[i] = Arrays.copyOf(temp, temp.length);
     }
     
     System.out.println("New matrix: ");
     for (int i = 0; i < b.length; i++){
         for (int j = 0; j < b[i].length; j++)
             System.out.print(b[i][j] + "    ");
         System.out.println();
     }
}
}