package z5_1;

public abstract class Figure {

    // абстрактный метод для получения периметра
    public abstract float getPerimeter();
    // абстрактный метод для получения площади
    public abstract double getArea();

}
