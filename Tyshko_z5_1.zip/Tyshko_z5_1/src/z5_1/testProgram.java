package z5_1;

import java.util.Arrays;

public class testProgram {

    static void sortAndPrint( Point[] pl, int sortBy )  {
        // printout in table
        System.out.println( "----- Sorted by: " + Point.getSortByName(sortBy));
        Arrays.sort( pl, Point.getComparator(sortBy));
        System.out.print( Point.format() );
        System.out.println();
        for( Point cnt : pl ) {
            System.out.println( Point.format( cnt ) );
        }
    }
    public static void main(String[] args) {
        try {
            Point[] pl = new Point[4];
            pl[0] = new Point( "A|1|3" );
            pl[1] = new Point( "B|1|6" );
            pl[2] = new Point( "C|9|6" );
            pl[3] = new Point( "D|9|3" );
            //Rectangle rect = "4 6 | 5 6 | 6 7";
            for(Object e: pl) System.out.println(e);
            //new Point("Test exception object");
            Rectangle example = new Rectangle(pl,4, "red", "white");
            
            sortAndPrint( pl, 0);
            sortAndPrint( pl, 1 );
            sortAndPrint( pl, 2 );

            // exception test:
            example.Print();

        }
        catch ( Exception e ) {
            System.out.println( "Exception: " + e );
        }
    }

}
