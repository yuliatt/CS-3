package z5_1;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;

public class Point implements
        Comparable <Point>,
        Iterable<String>, Iterator<String> {

    int x;
    int y;

    public static class ArgException extends Exception {
        private static final long serialVersionUID = 1L;

        ArgException( String arg ) {
            super( "Invalid argument: " + arg );
        }
    }

    ///////////////////////////////////////////////////
    // area names

    public static final String[] names =
            {
                    "Name",
                    "Cord_1",
                    "Cord_2"
            };

    //format strings for area printout
    public static String[] formatStr =  {
            "%-9s",   //
            "%-9s",   //
            "%-9s",   //
    };

    ///////////////////////////////////////////////////
    // sort
    public static String getSortByName(int sortBy) {
        return Point.names[sortBy];
    }

    public static Comparator<Point> getComparator(int sortBy) {
        if ( sortBy >= names.length || sortBy < 0 ) {
            throw new IndexOutOfBoundsException();
        }
        return new Comparator<Point> () {
            @Override
            public int compare(Point c0, Point c1) {
                return c0.points[sortBy].compareTo( c1.points[sortBy]);
            }
        };
    }

    /////////////////////////////////////////
    // areas container
    public String[] points = null;

    // indexator:
    public int length() {
        return points.length;
    }
    public String getPoints( int idx ) {
        if ( idx >= length() || idx < 0 ) {
            throw new IndexOutOfBoundsException();
        }
        return points[idx];
    }

    public void setPoints( int idx, String value ) throws ArgException {
        if ( idx >= length() || idx < 0 ) {
            throw new IndexOutOfBoundsException();
        }
        points[idx] = value;
    }

    //Iterable<String>, Iterator<String>
    public Iterator<String> iterator() {
        reset();
        return this;
    }

    private int iterator_idx = 0;
    public void reset() {
        iterator_idx = 0;
    }
    public boolean hasNext() {
        return iterator_idx >= points.length ? false: true;
    }
    public void remove() {
        //
    }
    public String next() {
        if ( iterator_idx < points.length ) {
            return points[iterator_idx++];
        }
        reset();
        return null;
    }
    //Comparable<Contact>
    public int compareTo( Point p ) {
        return points[0].compareTo( p.points[0] );
    }
    // toString
    public String toString() {
        if ( points == null ) {
            return " | | ";
        }
        String res = points[0];
        for ( int i = 1; i < points.length; i++ ) {
            res += "|" + points[i];
        }
        return res;
    }
    // constructors:
    //public Contact() {}
    private void setup( String[] args ) throws ArgException {
        if ( args == null ) {
            throw new ArgException( "null pointer passed for args" );
        }
        if ( args.length < 2 || args.length > names.length ) {
            throw new ArgException( Arrays.toString( args ));
        }
        points = new String[names.length];
        int i = 0;
        for (; i < args.length; i++ ) {
            setPoints( i, args[i] );
            if (i==1)
                x = Integer.valueOf(args[i]);
            if (i==2)
                y = Integer.valueOf(args[i]);

        }
        while ( i < names.length ) {
            points[i++] = "";
        }
    }
    public Point( String str ) throws ArgException {
        if ( str == null ) {
            throw new ArgException( "null pointer passed for str" );
        }

        // count tokens:
        int num = 1, idx = 0, idxFrom = 0;
        while (( idx = str.indexOf( '|', idxFrom ))!= -1 )
        {
            idxFrom = idx + 1;
            num++;
        }

        // allocate array
        String[] args = new String[num];

        // put all tokens to array
        idx = 0; idxFrom = 0; num = 0;
        while (( idx = str.indexOf( '|', idxFrom ))!= -1 )
        {
            args[num++] = str.substring( idxFrom, idx );
            idxFrom = idx + 1;
        }
        args[num] = str.substring( idxFrom );
        setup( args );
    }

    public Point( String...args ) throws ArgException {
        setup( args );
    }

    private static String format( Iterable<String> what ) {
        String result = "";
        int idx = 0;
        for( String str : what ) {
            result += String.format( formatStr[idx++], str );
        }
        return result;
    }

    public static String format() {
        return Point.format( Arrays.asList(Point.names ));
    }

    public static String format( Point cn ) {
        return Point.format(((Iterable<String>) cn ));
    }

}

