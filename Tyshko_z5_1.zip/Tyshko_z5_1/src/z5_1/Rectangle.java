package z5_1;

import z5_1.Point.ArgException;

public class Rectangle extends Figure {
    private double side[];
    private String fillcol;
    private String contourcol;

    private double[] Sides(Point arr[], int n) {
        double sides[] = new double [n];
        double dx, dy;
        for (int i = 0; i < n-1; i++) {
            dx = (arr[i].x-arr[i+1].x);
            dy = (arr[i].y-arr[i+1].y);
            sides[i] = Math.sqrt(dx*dx + dy*dy);
        }
        dx = (arr[n-1].x-arr[0].x);
        dy = (arr[n-1].y-arr[0].y);
        sides[n-1] = Math.sqrt(dx*dx + dy*dy);
        return sides;
    }

    Rectangle(Point mas[], int n, String contCol, String fcol){
        this.side = Sides(mas, n);
        this.contourcol = contCol;
        this.fillcol = fcol;
    }

    public float getPerimeter(){
        float P = 0;
        for (int i = 0; i<4; i++) {
            P +=side[i];
        }
        return P;
    }

    public double getArea(){
        double a = side[0];
        double b = side[1];
        return a*b;
    }

    void Print() {
        System.out.println("Fill Color is " + fillcol
                + "\nContour Color is " + contourcol
                + "\nArea = " + getArea()
                + "\nPerimeter = " + getPerimeter());
    }

}
