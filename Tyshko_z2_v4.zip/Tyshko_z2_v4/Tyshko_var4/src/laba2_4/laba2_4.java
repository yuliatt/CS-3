//����� ���� 11� ������ ���� 2, ������� 4

//����������
//�����������
//ddffssll
//�����������

package laba2_4;

import java.util.Scanner;

public class laba2_4 {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		String str /*= args[0]*/, out, tmp = "";
		char counter;
		while(in.has_next_line) 
		{
			if (str.length()== 0)
			{
				System.out.println("String is empty!");
				continue;
			}
			System.out.print("String: ");
			str = sc.nextLine();
			for(int i=0; i < str.length(); i++)
			{
				counter = str.charAt(i);
				tmp+=counter;
				for(int j = i; j < str.length(); j++)
				{
					if( j == str.length() -1 )
					{
						out = counter + String.valueOf(tmp.length());
						System.out.print(out);
						i = j;
						break;
					}
					if(str.charAt(j+1) == counter)
					{
						tmp+=str.charAt(j);
					}
					else if(str.charAt(j+1) == counter && (j+1) == str.length())
					{
						out = counter + String.valueOf(tmp.length());
						System.out.print(out);
						i = j;
						break;
					}
					else
					{
						out = counter + String.valueOf(tmp.length());
						System.out.print(out);
						i = j;
						break;
					}
				}
				tmp="";
			}
			System.out.println();
		}
	}
}

